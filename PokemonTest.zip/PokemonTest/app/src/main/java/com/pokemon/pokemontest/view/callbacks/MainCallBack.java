package com.pokemon.pokemontest.view.callbacks;


public interface MainCallBack extends BaseCallBack {
    public void showError(String msg);
    public void showSuccess(String msg);


}
