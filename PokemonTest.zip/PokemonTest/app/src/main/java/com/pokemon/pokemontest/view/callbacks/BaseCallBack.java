package com.pokemon.pokemontest.view.callbacks;

/**
 * Created by faisalza on 6/1/2018.
 */

public interface BaseCallBack {
  public void initViews();


}
