package com.pokemon.pokemontest.data;

public class SessionManager {

}