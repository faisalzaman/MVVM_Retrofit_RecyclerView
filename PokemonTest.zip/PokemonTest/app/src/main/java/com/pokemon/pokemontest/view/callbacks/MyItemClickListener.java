package com.pokemon.pokemontest.view.callbacks;

import android.view.View;

public interface MyItemClickListener {
    public void onClick(View view,int position);
}
