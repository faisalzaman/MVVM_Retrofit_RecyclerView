package com.pokemon.pokemontest.view.ui;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.pokemon.pokemontest.R;
import com.pokemon.pokemontest.data.model.Pokemon;
import com.pokemon.pokemontest.utils.Constants;
import com.pokemon.pokemontest.view.callbacks.MainCallBack;
import com.pokemon.pokemontest.view.fragments.Frg_PokemonDetail;
import com.pokemon.pokemontest.viewmodel.MainViewModel;

public class MainActivity extends BaseActivity<MainViewModel> implements MainCallBack {

    TextView tvToolbarTitle;
    ImageView ivToolbarback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getViewModel().setCallBack(this);
        initViews();
        setUpToolBar();
    }

    @Override
    public int getLayout() {
        return R.layout.activity_main;
    }

    @Override
    public MainViewModel initViewModel() {
        return new MainViewModel();
    }

    private void setUpToolBar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        tvToolbarTitle = findViewById(R.id.toolbar_title);
        ivToolbarback = findViewById(R.id.iv_back);
        ivToolbarback.setVisibility(View.INVISIBLE);

        ivToolbarback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ivToolbarback.setVisibility(View.INVISIBLE);
                tvToolbarTitle.setText("Pokemon");
                Constants.FLAG="main" ;

                getSupportFragmentManager().popBackStack("detail", getSupportFragmentManager().POP_BACK_STACK_INCLUSIVE);
            }
        });

        tvToolbarTitle.setText("Pokemon");
        setSupportActionBar(toolbar);
//        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back);

    }

    @Override
    public void showError(String msg) {

    }

    @Override
    public void showSuccess(String msg) {

    }

    @Override
    public void initViews() {


    }

    public void gotoDetail(int pos){

        Constants.FLAG="detail";
        ivToolbarback.setVisibility(View.VISIBLE);

        Fragment frgDetail = Frg_PokemonDetail.getInstance();
        Bundle bundle = new Bundle();
        bundle.putInt("position",pos);
        frgDetail.setArguments(bundle);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.list_fragment,frgDetail);
        transaction.addToBackStack("detail");
        transaction.commit();

        Pokemon pokemon = Constants.pokemonsArrayList.get(pos);
        tvToolbarTitle.setText(pokemon.getName());
    }



    // This method is used to set the default fragment that will be shown.
    public void setDefaultFragment(Fragment defaultFragment)
    {
        this.replaceFragment(defaultFragment);
    }

    public void replaceFragment(Fragment destFragment)
    {

        Constants.FLAG="detail";
        ivToolbarback.setVisibility(View.VISIBLE);

        // First get FragmentManager object.
        FragmentManager fragmentManager = this.getSupportFragmentManager();

        // Begin Fragment transaction.
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        // Replace the layout holder with the required Fragment object.
        fragmentTransaction.replace(R.id.list_fragment, destFragment);

        // Commit the Fragment replace action.
        fragmentTransaction.commit();
    }
}
