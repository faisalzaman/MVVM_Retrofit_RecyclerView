package com.pokemon.pokemontest.utils;

import com.pokemon.pokemontest.data.model.Pokemon;

import java.util.ArrayList;

public class Constants {
    //      development server
    public static String BASE_URL = "https://raw.githubusercontent.com/Biuni/PokemonGO-Pokedex/master/";
    public static ArrayList<Pokemon> pokemonsArrayList = new ArrayList<>();
    public static String FLAG = "main";
}
