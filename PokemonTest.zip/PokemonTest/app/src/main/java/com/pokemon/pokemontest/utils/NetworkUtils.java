
package com.pokemon.pokemontest.utils;


/**
 * Created by faisalza on 6/1/2018.
 */

public final class NetworkUtils {

    private NetworkUtils() {
    }


}