package com.pokemon.pokemontest.utils;


/**
 * Created by faisalza on 6/1/2018.
 */

public class Config {

//    public final static String BASE_URL = "http://172.26.50.69:55588/";


}
